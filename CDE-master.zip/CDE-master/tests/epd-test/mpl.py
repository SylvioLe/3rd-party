import numpy
import matplotlib

x = numpy.array([1,2,3])
print x
