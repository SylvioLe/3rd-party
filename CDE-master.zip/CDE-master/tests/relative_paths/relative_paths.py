for line in open('../test_file.link'):
  print line,

for line in open('../test_file.txt'):
  print line,

