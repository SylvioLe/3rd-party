import os

# spawn a sub-process
os.system('python numpy_scipy_test.py')
