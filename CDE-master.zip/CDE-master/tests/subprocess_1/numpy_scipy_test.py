# dynamically load a crap-load of libraries!
import numpy
import scipy

x = numpy.array([1, 2, 3, 4, 5])
print x

